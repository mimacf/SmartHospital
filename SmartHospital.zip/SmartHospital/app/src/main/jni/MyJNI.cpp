//
// Created by 38163 on 09/06/2021.
//
#include "mirjana_nikolic_smarthospital_JNI.h"

JNIEXPORT jint JNICALL Java_mirjana_nikolic_smarthospital_JNI_hashPassword
  (JNIEnv * jnienv, jobject jobj, jint passToHash, jint hashKey)

  {
        return passToHash^hashKey;
  }

JNIEXPORT jint JNICALL Java_mirjana_nikolic_smarthospital_JNI_unhashPassword
   (JNIEnv * jnienv, jobject jobj, jint unhashKey, jint hashedPass)

  {
        return unhashKey^hashedPass;
  }
