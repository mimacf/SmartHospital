package mirjana.nikolic.smarthospital;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

public class AdminAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<AdminView> adminviews;
    private static String HTTP_POST_STATE = "http://192.168.1.51:8080/api/device/";
    private HttpHelper httpHelper;

    public AdminAdapter(Context context) {
        this.context = context;
        adminviews = new ArrayList<AdminView>();

    }

    @Override
    public int getCount() {
        return adminviews.size();
    }

    @Override
    public Object getItem(int position) {
        if(position >= 0)
        {
            return adminviews.get(position);
        }
        else
        {
            return null;
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    public void addElement(AdminView element)
    {
        adminviews.add(element);
        notifyDataSetChanged();
    }
    public void update(AdminView[] uredjaji)
    {
        adminviews.clear();
        if(uredjaji !=null)
        {
            for(AdminView uredjaj: uredjaji)
            {
                adminviews.add(uredjaj);
            }
        }
        notifyDataSetChanged();
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null)
        {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.adminview, null);

            ViewHolder vh = new ViewHolder();
            vh.neaktivan = convertView.findViewById(R.id.neaktivan);
            vh.uredjaj = convertView.findViewById(R.id.nazivuredjaja);
            vh.slika = convertView.findViewById(R.id.slikaUredjaj);
            vh.dugme = convertView.findViewById(R.id.dugme_uredjaja);
           // vh.dugme.setTag(position);
            vh.neaktivan.setTag(position);
            convertView.setTag(vh);
        }
        AdminView av = (AdminView) getItem(position);
        ViewHolder vh = (ViewHolder) convertView.getTag();
        vh.uredjaj.setText(av.getUredjaj());
        vh.slika.setImageResource(av.getSlika());
        //vh.dugme.setTag(av.isDugme());


        vh.dugme.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                String id_uredjaja = av.getID();
                httpHelper = new HttpHelper();
                if(isChecked) {
                    vh.neaktivan.setVisibility(View.INVISIBLE);
                    vh.dugme.setChecked(isChecked);
                    av.setDugme(isChecked);
                    vh.dugme.setTag(position);
                }
                else
                {
                    vh.neaktivan.setVisibility(View.VISIBLE);
                    av.setDugme(isChecked);
                    vh.dugme.setTag(position);
                    vh.dugme.setChecked(isChecked);
                }
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            String state = null;
                            if(isChecked){
                                state = "on";
                            } else {
                                state = "off";
                            }
                            String url = HTTP_POST_STATE + String.valueOf(id_uredjaja) + "/" + state ;


                            JSONObject check = httpHelper.POSTJSONObjectFromURL(url);
                            Log.d("Zahtev Post_state uspeo?: ", check.toString());
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();

            }
        });


        return convertView;

    }

    public class ViewHolder{
        public TextView uredjaj = null;
        public ImageView slika = null;
        public Switch dugme = null;
        public TextView neaktivan = null;

    }
}


