package mirjana.nikolic.smarthospital;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Random;

public class AddDevice extends AppCompatActivity implements View.OnClickListener {


    private EditText ime_uredjaja_ovog;
    private EditText tip_uredjaja_ovog;
    private Button dugme_sacuvaj_ovog;
    private HttpHelper httpHelper;
    private SmartHospitalDb dataBase;


    public static String POST_DEVICE = "http://192.168.1.4:8080/api/device";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_device);

        ime_uredjaja_ovog = findViewById(R.id.ime_uredjaja_ovog);
        tip_uredjaja_ovog = findViewById(R.id.tip_uredjaja_ovog);
        dugme_sacuvaj_ovog = findViewById(R.id.dugme_sacuvaj_ovog);

        dugme_sacuvaj_ovog.setOnClickListener(this);

        httpHelper = new HttpHelper();
        dataBase = new SmartHospitalDb(this);

    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.dugme_sacuvaj_ovog){

            if (ime_uredjaja_ovog.getText().length() <= 0 && tip_uredjaja_ovog.getText().length() <= 0) {
                Toast.makeText(getApplicationContext(), "Niste uneli potrebne podatke", Toast.LENGTH_LONG).show();
            } else {
                String name = ime_uredjaja_ovog.getText().toString();
                String type = tip_uredjaja_ovog.getText().toString();


                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {

                            Random rn = new Random();
                            int answer = rn.nextInt(10) + 1;

                            String value = "" + answer + "";

                            JSONObject json = new JSONObject();
                            try{
                                json.put("name", name);
                                json.put("id",  value);
                                json.put("state", "off");
                                json.put("type", type);
                                Log.d("Json_obj-> ", json.toString());

                            } catch (JSONException e) {

                                e.printStackTrace();
                            }

                            JSONObject jsonObject = httpHelper.PostJSONObjectFromURL(POST_DEVICE, json);

                            String ime = json.getString("name");
                            String id = json.getString("id");
                            String st = json.getString("state");
                            //u sql bazi ne cuvamo tip uredjaja, pa nam taj parametar ne treba
                            boolean stanje;
                            if (st.toUpperCase().equals("ON")) {
                                stanje = true;
                            } else {
                                stanje = false;
                            }

                            Log.d("JSON-obj_USPESNO DODAT: ", jsonObject.toString());


                            String poruka = jsonObject.getString("message");
                            String kodGreske = jsonObject.getString("code");
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if(kodGreske.equals("200")) {
                                        Toast.makeText(getApplicationContext(), "Successfuly!", Toast.LENGTH_LONG).show();


                                        if(id.equals("1")) {
                                            AdminView av = new AdminView(id, ime, R.drawable.senzor_temp, stanje);
                                            av.setDugme(stanje);
                                            dataBase.insertUredjaji(av);
                                        } else if (id.equals("2")) {
                                            AdminView av = new AdminView(id, ime, R.drawable.senzor_osvetljenja, stanje);
                                            av.setDugme(stanje);
                                            dataBase.insertUredjaji(av);
                                        } else if (id.equals("3")) {
                                            AdminView av = new AdminView(id, ime, R.drawable.senzor_pokreta, stanje);
                                            av.setDugme(stanje);
                                            dataBase.insertUredjaji(av);
                                        } else {
                                            AdminView av = new AdminView(id, ime, R.drawable.senzor_osvetljenja, stanje);
                                            av.setDugme(stanje);
                                            dataBase.insertUredjaji(av);
                                        }
                                    } else {
                                        Toast.makeText(getApplicationContext(), poruka.toString() + " Error: " + kodGreske.toString(), Toast.LENGTH_LONG).show();
                                    }
                                }
                            });



                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();



            }

        }



    }
}
