package mirjana.nikolic.smarthospital;

public class JNI {

    static
    {
        System.loadLibrary("PassHash");
    }
    public native int hashPassword(int passToHash, int hashKey);
    public native int unhashPassword(int unhashKey, int hashedPass);
}
