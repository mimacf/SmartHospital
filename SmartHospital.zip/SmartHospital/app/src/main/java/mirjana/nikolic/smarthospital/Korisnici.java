package mirjana.nikolic.smarthospital;

public class Korisnici {
    public static int id = 0;
    public String ime, prezime, pol, username, datum;
    public int password;

    public Korisnici(String ime, String prezime, String pol, String username, int password, String datum) {
        this.ime = ime;
        this.prezime = prezime;
        this.pol = pol;
        this.username = username;
        this.password = password;
        this.datum = datum;
        id++;
    }

    public static int getId() {
        return id;
    }

    public static void setId(int id) {
        Korisnici.id = id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getPol() {
        return pol;
    }

    public void setPol(String pol) {
        this.pol = pol;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getPassword() {
        return password;
    }

    public void setPassword(int password) {
        this.password = password;
    }

    public String getDatum() {
        return datum;
    }

    public void setDatum(String datum) {
        this.datum = datum;
    }
}
