package mirjana.nikolic.smarthospital;


import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

public class Binder extends IBinder.Stub {
    public static String GET_ALL_DEVICES = "http://192.168.0.11:8080/api/devices/";

    private NewDevices mCaller;
    private Context context;

    public Binder (Context context)
    {
        this.context=context;
    }

    public void start() throws RemoteException
    {
        mCaller=new NewDevices(context);
        mCaller.start();
    }

    public void stop() throws RemoteException
    {
        mCaller.stop();
    }

    private class NewDevices implements Runnable
    {
        private Handler mHandler=null;
        private static final long PERIOD = 3000L;
        private boolean mRun=true;
        private HttpHelper httpHelper;
        private SmartHospitalDb DBhelper;
        public AdminAdapter adapter;

        private NewDevices(Context context)
        {
            httpHelper=new HttpHelper();
            DBhelper=new SmartHospitalDb(context);
            adapter=AdminActivity.adapter;
        }


        public void start()
        {
            mHandler=new Handler(Looper.getMainLooper());
            mHandler.postDelayed(this,PERIOD);
        }

        private void stop()
        {
            mRun=false;
            mHandler.removeCallbacks(this);
        }



        @Override
        public void run()
        {
            if(!mRun)return;
            DBhelper.deleteUredjaji();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        JSONArray jsonobject = httpHelper.getJSONArrayFromURL(GET_ALL_DEVICES); //dobili smo json objekat sada
                        //jsonobject = [{}, {}, .... , {} ]
                        Log.e("Duzina niza: ", "ovo je: " + jsonobject.length());
                        for (int i = 0; i < jsonobject.length(); i++) {
                            //for each el of json arr, take one json obj
                            JSONObject el = jsonobject.getJSONObject(i);
                            Log.d("JSON data- ", el.toString());
                            String ime = el.getString("name");
                            String id = el.getString("id");
                            String st = el.getString("state");
                            boolean stanje;
                            if (st.toUpperCase().equals("ON")) {
                                stanje = true;
                            } else {
                                stanje = false;
                            }

                            if(id.equals("1")) {
                                AdminView av = new AdminView(id, ime, R.drawable.senzor_temp, stanje);
                                av.setDugme(stanje);
                                DBhelper.insertUredjaji(av);
                            } else if (id.equals("2")) {
                                AdminView av = new AdminView(id, ime, R.drawable.senzor_osvetljenja, stanje);
                                av.setDugme(stanje);
                                DBhelper.insertUredjaji(av);
                            } else if (id.equals("3")) {
                                AdminView av = new AdminView(id, ime, R.drawable.senzor_temp, stanje);
                                av.setDugme(stanje);
                                DBhelper.insertUredjaji(av);
                            } else if (id.equals("4")) {
                                AdminView av = new AdminView(id, ime, R.drawable.senzor_temp, stanje);
                                av.setDugme(stanje);
                                DBhelper.insertUredjaji(av);
                            } else {
                                AdminView av = new AdminView(id, ime, R.drawable.senzor_pokreta, stanje);
                                av.setDugme(stanje);
                                DBhelper.insertUredjaji(av);

                            };


                        }
                        AdminActivity.runOnUI(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    AdminView[] uredjaji = DBhelper.readUredjaji();
                                    AdminActivity.adapter.update(uredjaji);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                    } catch (JSONException | IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
            mHandler.postDelayed(this,PERIOD);
        }
    }
}
