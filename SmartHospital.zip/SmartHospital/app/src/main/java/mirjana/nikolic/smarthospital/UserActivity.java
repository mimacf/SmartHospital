package mirjana.nikolic.smarthospital;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

public class UserActivity extends AppCompatActivity {

    private ListView lista;
    private UserAdapter UserAdapter;
    private SmartHospitalDb dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        lista = findViewById(R.id.Lista);
        UserAdapter = new UserAdapter( this);
        lista.setAdapter(UserAdapter);


        dbHelper = new SmartHospitalDb(this);


        userview uv1 = new userview(getString(R.string.Datum),getString(R.string.Kontrola));
        userview uv2 = new userview(getString(R.string.Datum1),getString(R.string.Kontrola1));
        userview uv3 = new userview(getString(R.string.Datum2),getString(R.string.Kontrola2));
        userview uv4 = new userview(getString(R.string.Datum3),getString(R.string.Kontrola3));

        userview[] pregledi = dbHelper.readPregledi();
        if(pregledi.length > 0)
        {
            dbHelper.deletePreglede();
        }

        dbHelper.insertPregledi(uv1);
        dbHelper.insertPregledi(uv2);
        dbHelper.insertPregledi(uv3);
        dbHelper.insertPregledi(uv4);


    }
    protected void onResume()
    {
        super.onResume();
        userview[] pregledi=dbHelper.readPregledi();
        UserAdapter.update(pregledi);
    }
}