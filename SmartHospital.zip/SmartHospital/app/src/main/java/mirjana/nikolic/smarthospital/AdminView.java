package mirjana.nikolic.smarthospital;

import android.graphics.drawable.Drawable;
import android.widget.TextView;

public class AdminView {

    private String ID;
    private String uredjaj;
    private int slika;
    private boolean dugme;
    private TextView neaktivan;

    public AdminView(String ID, String uredjaj, int slika, boolean dugme) {
        this.ID = ID;
        this.uredjaj = uredjaj;
        this.slika = slika;
        this.dugme = dugme;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setUredjaj(String uredjaj) {
        this.uredjaj = uredjaj;
    }

    public void setSlika(int slika) { this.slika = slika; }

    public void setDugme(boolean dugme) {
        this.dugme = dugme;
    }

    public void setNeaktivan(TextView neaktivan) {
        this.neaktivan = neaktivan;
    }

    public String getUredjaj() {
        return uredjaj;
    }

    public int getSlika() {
        return slika;
    }

    public boolean isDugme() {
        return dugme;
    }

    public TextView getNeaktivan() {
        return neaktivan;
    }
}
