package mirjana.nikolic.smarthospital;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.sql.SQLClientInfoException;

public class SmartHospitalDb extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "SmartHospital.db";
    public static final int DATABASE_VERSION =1;

    //Tabela Korisnici
    public static final String K_TABLE_NAME="KORISNICI";
    public static final String K_ID = "ID";
    public static final String K_USERNAME="USERNAME";
    public static final String K_IME="IME";
    public static final String K_PREZIME="PREZIME";
    public static final String K_POL="POL";
    public static final String K_PASSWORD="PASSWORD";
    public static final String K_DATUM="DATUM";

    //Tabela Uredjaji
    public static final String U_TABLE_NAME = "UREDJAJI";
    public static final String U_ID = "ID";
    public static final String U_IMAGE = "SLIKA";
    public static final String U_NAZIV = "Naziv";
    public static final String U_SWITCH="SWITCH";

    //Tabela pregledi
    public static final String P_TABLE_NAME = "PREGLEDI";
    public static final String P_ID = "ID";
    public static final String P_DATUM = "DATUM";
    public static final String P_PREGLED = "PREGLED";



    public SmartHospitalDb(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }



    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + K_TABLE_NAME + "(" + K_ID + " INTEGER, " + K_IME+ " TEXT, " + K_PREZIME + " TEXT, " + K_POL + " TEXT, "  + K_USERNAME + " TEXT, "+ K_PASSWORD + " TEXT, " + K_DATUM + " TEXT);");
        db.execSQL("CREATE TABLE " + U_TABLE_NAME + "(" + U_ID + " TEXT, " + U_NAZIV + " TEXT, " + U_IMAGE + " INTEGER, " + U_SWITCH + " INTEGER);");
        db.execSQL("CREATE TABLE " + P_TABLE_NAME + "(" + P_ID + " INTEGER, " + P_DATUM + " TEXT, "+ P_PREGLED  + " TEXT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertKorisnik(Korisnici korisnik)
    {
        //tabela korisnici
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values=new ContentValues();

        values.put(K_ID,korisnik.getId());
        values.put(K_IME,korisnik.getIme());
        values.put(K_PREZIME,korisnik.getPrezime());
        values.put(K_POL,korisnik.getPol());
        values.put(K_USERNAME,korisnik.getUsername());
        values.put(K_PASSWORD,korisnik.getPassword());
        values.put(K_DATUM,korisnik.getDatum());

        db.insert(K_TABLE_NAME,null,values);

        close();
    }
    public void insertUredjaji(AdminView av)
    {
        SQLiteDatabase db = getWritableDatabase();

        //tabela uredjaji
        ContentValues values3=new ContentValues();
        values3.put(U_ID, av.getID());
        values3.put(U_IMAGE, av.getSlika());
        values3.put(U_NAZIV, av.getUredjaj());
        values3.put(U_SWITCH, av.isDugme());

        db.insert(U_TABLE_NAME, null, values3);


        close();
    }

    public void insertPregledi(userview uv)
    {
        SQLiteDatabase db = getWritableDatabase();


        ContentValues values3=new ContentValues();
        values3.put(P_DATUM, uv.getDatum());
        values3.put(P_PREGLED, uv.getKontrola());

        db.insert(P_TABLE_NAME, null, values3);


        close();
    }


    public Korisnici[] readKorisnik()
    {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor= db.query(K_TABLE_NAME,null,null,null,null,null,null);

        if(cursor.getCount()<=0)
        {
            return null;
        }
        Korisnici[] korisnici=new Korisnici[cursor.getCount()];

        int i=0;
        for(cursor.moveToFirst();!cursor.isAfterLast();cursor.moveToNext())
        {
            korisnici[i++]=createKorisnik(cursor);
        }

        close();
        return korisnici;
    }
    public AdminView[] readUredjaji()
    {
        SQLiteDatabase db=getReadableDatabase();
        Cursor cursor= db.query(U_TABLE_NAME,null,null,null,null,null,null);

        if(cursor.getCount()<0)
        {
            return null;
        }

        AdminView[] av = new AdminView[cursor.getCount()];
        int i=0;
        for(cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext())
        {
            av[i++] = createUredjaji(cursor);
        }

        close();
        return av;
    }


    public userview[] readPregledi()
    {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor= db.query(P_TABLE_NAME,null,null,null,null,null,null);

        if(cursor.getCount()<0)
        {
            return null;
        }
        userview[] pregledi=new userview[cursor.getCount()];

        int i=0;
        for(cursor.moveToFirst();!cursor.isAfterLast();cursor.moveToNext())
        {
            pregledi[i++]=createPregled(cursor);
        }

        close();
        return pregledi;
    }

    private Korisnici createKorisnik (Cursor cursor)
    {
        String ime=cursor.getString(cursor.getColumnIndex(K_IME));
        String prezime=cursor.getString(cursor.getColumnIndex(K_PREZIME));
        String pol=cursor.getString(cursor.getColumnIndex(K_POL));
        String username=cursor.getString(cursor.getColumnIndex(K_USERNAME));
        int password=cursor.getInt(cursor.getColumnIndex(K_PASSWORD));
        String datum=cursor.getString(cursor.getColumnIndex(K_DATUM));

        return new Korisnici(ime, prezime, pol, username, password, datum);
    }

    private userview createPregled(Cursor cursor)
    {
        String datum=cursor.getString(cursor.getColumnIndex(P_DATUM));
        String pregled=cursor.getString(cursor.getColumnIndex(P_PREGLED));
        return new userview(datum, pregled);
    }
    private AdminView createUredjaji(Cursor cursor)
    {
        String id = cursor.getString(cursor.getColumnIndex(U_ID));
        String naziv = cursor.getString(cursor.getColumnIndex(U_NAZIV));
        int image = cursor.getInt(cursor.getColumnIndex(U_IMAGE));
        int sw = cursor.getInt(cursor.getColumnIndex(U_SWITCH));
        boolean sw1;

        if(sw == 1)
        {
            sw1 = true;
        } else
        {
            sw1 = false;
        }
        return new AdminView(id, naziv, image, sw1);
    }



    public void  deletePreglede()
    {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(P_TABLE_NAME, null, null);
        close();
    }

    public void  deleteUredjaji()
    {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(P_TABLE_NAME, null, null);
        close();
    }


    public boolean findKorisnikByUsername(String username)
    {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor= db.query(K_TABLE_NAME, null, K_USERNAME + " = ? ",new String[] {username},null,null,null);

        if(cursor.getCount() <= 0)
        {
            return false;
        }

        return true;
    }
    public boolean findKorisnikByPassword(String password)
    {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor= db.query(K_TABLE_NAME, null, K_PASSWORD + " = ? ",new String[] {password},null,null,null);

        if(cursor.getCount() <= 0)
        {
            return false;
        }

        return true;
    }
}
