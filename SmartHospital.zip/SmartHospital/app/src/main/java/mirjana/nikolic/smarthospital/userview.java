package mirjana.nikolic.smarthospital;

public class userview {
    private String datum;
    private String kontrola;

    public String getDatum() {
        return datum;
    }

    public void setDatum(String datum) {
        this.datum = datum;
    }

    public String getKontrola() {
        return kontrola;
    }

    public void setKontrola(String kontrola) {
        this.kontrola = kontrola;
    }

    public userview(String datum, String kontrola) {
        this.datum = datum;
        this.kontrola = kontrola;
    }
}
