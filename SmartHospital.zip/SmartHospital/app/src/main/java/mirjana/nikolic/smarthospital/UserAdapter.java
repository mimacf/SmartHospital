package mirjana.nikolic.smarthospital;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class UserAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<userview>userviews;

    public UserAdapter(Context context) {
        this.context = context;
        userviews = new ArrayList<userview>();
    }
    public void addElement(userview element)
    {
        userviews.add(element);
        notifyDataSetChanged();

    }

    @Override
    public int getCount() {
        return userviews.size();
    }

    @Override
    public Object getItem(int position) {
        if(position >= 0)
        {
            return userviews.get(position);
        }
        else
        {
            return null;
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void update(userview[] pregledi)
    {
        userviews.clear();
        if(pregledi != null)
        {
            for(userview uv : pregledi)
            {
                userviews.add(uv);
            }
        }
        notifyDataSetChanged();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null)
        {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.userview, null);

        }

        userview podaci = (userview)getItem(position);
        TextView datum = convertView.findViewById(R.id.datum);
        TextView kontrola = convertView.findViewById(R.id.kontrola);

        datum.setText(podaci.getDatum());
        kontrola.setText(podaci.getKontrola());
        return convertView;

    }
}
