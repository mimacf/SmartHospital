package mirjana.nikolic.smarthospital;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

import static android.widget.Toast.LENGTH_SHORT;


public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {
    JNI jni = new JNI();

    Button submit;
    TextView prazno;
    TextView username;
    EditText ime,prezime, password;
    String name,lastname;
    String predstavi_se;

    RadioButton musko,zensko,ostalo;
    CalendarView kalendar;

    private SmartHospitalDb dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        submit = findViewById(R.id.Submit);
        submit.setOnClickListener(this);

        username = findViewById(R.id.Username);
        prazno = findViewById(R.id.prazan);
        ime = findViewById(R.id.text_uneti_ime);
        prezime = findViewById(R.id.text_uneti_prezime);
        password = findViewById(R.id.text_uneti_lozinku);
        musko = findViewById(R.id.text_M);
        zensko = findViewById(R.id.text_z);
        ostalo = findViewById(R.id.text_Ostalo);
        kalendar = findViewById(R.id.kalendar);

        dbHelper = new SmartHospitalDb(this);
    }

    @Override
    public void onClick(View v) {
        String ime1 = ime.getText().toString();
        String prezime1 = prezime.getText().toString();
        String user1 = ime1 + "." + prezime1;
        String pol;
        String sifra;
        String datum;

        sifra = password.getText().toString();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        datum = sdf.format(new Date(kalendar.getDate()));
        if(musko.isChecked())
        {
            pol = "Musko";
        } else if (zensko.isChecked())
        {
            pol = "Zensko";
        } else
        {
            pol = "Ostalo";
        }
        if(!ime1.isEmpty() && !prezime1.isEmpty()){
            prazno.setText(user1);
            prazno.setVisibility(View.VISIBLE);
            username.setVisibility(View.VISIBLE);
            if(dbHelper.findKorisnikByUsername(user1))
            {
                String poruka = "Uneli ste postojeceg korisnika!";
                Toast.makeText(RegisterActivity.this, poruka, Toast.LENGTH_LONG).show();
            } else
            {
                int jni_sifra = jni.hashPassword(Integer.parseInt(sifra), 2234);
                Korisnici korisnik = new Korisnici(ime1, prezime1,pol, user1, jni_sifra, datum);
                dbHelper.insertKorisnik(korisnik);
                String poruka1 = "Unet je korisnik imena : ";
                Toast.makeText(RegisterActivity.this, poruka1, Toast.LENGTH_SHORT).show();
            }


        } else {
            prazno.setText("Niste uneli validne podatke");
            prazno.setVisibility(View.VISIBLE);
        }



    }
}