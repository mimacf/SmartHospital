package mirjana.nikolic.smarthospital;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

public class AdminActivity extends AppCompatActivity implements View.OnClickListener, ServiceConnection {

    public static AdminAdapter adapter;
    private HttpHelper HttpHelper;
    public static String GET_ALL_DEVICES = "http://192.168.1.51:8080/api/devices/";
    private ListView lista;
    private Button DodajUredjaj;
    private Button bindUredjaj;
    private Button unbindUredjaj;
    private mirjana.nikolic.smarthospital.IBinder binder = null;


    private SmartHospitalDb dbHelper;
    public static Handler UIHandler;

    static{
        UIHandler = new Handler(Looper.getMainLooper());
    }

    public static void runOnUI(Runnable runnable) {
        UIHandler.post(runnable);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        HttpHelper = new HttpHelper();

        lista = findViewById(R.id.admin_lista);
        adapter = new AdminAdapter(this);
        DodajUredjaj = findViewById(R.id.dodaj_uredjaj);
        DodajUredjaj = findViewById(R.id.dodaj_uredjaj);
        dbHelper = new SmartHospitalDb(this);
        bindUredjaj = findViewById(R.id.bind);
        unbindUredjaj = findViewById(R.id.unbind);
        lista.setAdapter(adapter);

        DodajUredjaj.setOnClickListener(this);

        bindUredjaj.setOnClickListener(this);
        unbindUredjaj.setOnClickListener(this);
/*
        AdminView av1 = new AdminView(getString(R.string.uredjaj_1), R.drawable.senzor_osvetljenja, false);
        AdminView av2 = new AdminView(getString(R.string.uredjaj_2), R.drawable.senzor_temp, false);
        AdminView av3 = new AdminView(getString(R.string.uredjaj_3), R.drawable.senzor_pokreta, false);
        AdminView av4 = new AdminView(getString(R.string.uredjaj_3), R.drawable.senzor_pokreta, false);
        AdminView av5 = new AdminView(getString(R.string.uredjaj_3), R.drawable.senzor_pokreta, false);
        AdminView av6= new AdminView(getString(R.string.uredjaj_2), R.drawable.senzor_temp, false);
        AdminView av7 = new AdminView(getString(R.string.uredjaj_3), R.drawable.senzor_pokreta, false);
        AdminView av8 = new AdminView(getString(R.string.uredjaj_3), R.drawable.senzor_pokreta, false);
        AdminView av9 = new AdminView(getString(R.string.uredjaj_3), R.drawable.senzor_pokreta, false);
        AdminView[] av = dbHelper.readUredjaji();

        if (av.length > 0) {
            dbHelper.deleteUredjaji();
        }

        dbHelper.insertUredjaji(av1);
        dbHelper.insertUredjaji(av2);
        dbHelper.insertUredjaji(av3);
        dbHelper.insertUredjaji(av4);
        dbHelper.insertUredjaji(av5);
        dbHelper.insertUredjaji(av6);
        dbHelper.insertUredjaji(av7);
        dbHelper.insertUredjaji(av8);
        dbHelper.insertUredjaji(av9);

*/
        dbHelper.deleteUredjaji();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONArray jsonobject = HttpHelper.getJSONArrayFromURL(GET_ALL_DEVICES); //dobili smo json objekat sada
                    for (int i = 0; i < jsonobject.length(); i++) {
                        JSONObject el = jsonobject.getJSONObject(i);
                        String ime = el.getString("name");
                        String id = el.getString("id");
                        String st = el.getString("state");
                        boolean stanje;
                        if (st.toUpperCase().equals("ON")) {
                            stanje = true;
                        } else {
                            stanje = false;
                        }

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if(id.equals("1")) {
                                    AdminView av = new AdminView(id, ime, R.drawable.senzor_temp, stanje);
                                    av.setDugme(stanje);
                                    dbHelper.insertUredjaji(av);
                                    adapter.addElement(av);
                                } else if (id.equals("2")) {
                                    AdminView av = new AdminView(id, ime, R.drawable.senzor_osvetljenja, stanje);
                                    av.setDugme(stanje);
                                    dbHelper.insertUredjaji(av);
                                    adapter.addElement(av);

                                } else if (id.equals("3")) {
                                    AdminView av = new AdminView(id, ime, R.drawable.senzor_pokreta, stanje);
                                    av.setDugme(stanje);
                                    dbHelper.insertUredjaji(av);
                                    adapter.addElement(av);

                                } else {
                                    AdminView av = new AdminView(id, ime, R.drawable.senzor_temp, stanje);
                                    av.setDugme(stanje);
                                    dbHelper.insertUredjaji(av);
                                    adapter.addElement(av);

                                };
                            }
                        });



                    }
                } catch (IOException e) {
                    //"There are no available devices"
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "There are no available devices!", Toast.LENGTH_LONG).show();
                        }
                    });

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }).start();

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(AdminActivity.this, DeviceActivity.class);
                AdminView av = (AdminView) adapter.getItem(position);

                intent.putExtra("key", av.getID());

                startActivity(intent);

            }

        });
    }

    protected void onResume() {
        super.onResume();
        AdminView[] uredjaji = dbHelper.readUredjaji();
        adapter.update(uredjaji);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.dodaj_uredjaj)
        {
            Intent intent = new Intent(AdminActivity.this, AddDevice.class);
            startActivity(intent);
        }
        else if(v.getId()==R.id.bind)
        {
            Intent intent=new Intent(this,BService.class);
            if(!bindService(intent,this, Context.BIND_AUTO_CREATE))
            {
                Log.d("MainActivity","Bind failed");
            }
            else
            {
                Log.d("MainActivity","Bind!");
            }


        }
        else if (v.getId()==R.id.unbind)
        {
            if(binder!=null) {
                Log.d("MainActivity","Unbind service");
                binder = null;
                unbindService(this);
            }
            else
            {
                Log.d("MainActivity","Service is null");
            }

        }
    }

    @Override
    public void onServiceConnected(ComponentName name, IBinder service) {
        binder = mirjana.nikolic.smarthospital.IBinder.Stub.asInterface(service);
        try {
            binder.start();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onServiceDisconnected(ComponentName name) {
        Log.d("MainActivity","onServiceDisconnectef-error");
        binder=null;

    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        if(binder!=null)
        {
            Log.d("MainActivity","unBind-onDestroy()");
            unbindService(this);
        }


    }
}
