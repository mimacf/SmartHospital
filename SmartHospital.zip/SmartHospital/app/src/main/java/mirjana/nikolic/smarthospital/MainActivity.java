package mirjana.nikolic.smarthospital;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    JNI jni = new JNI();
    TextView TV,username,password;
    ImageView IV;
    Button register,prijava,PRIJAVA;
    String USERNAME;
    String PASSWORD;
    private SmartHospitalDb dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TV = findViewById(R.id.text_view_id);
        IV = findViewById(R.id.image);
        username = findViewById(R.id.text_USERNAME);
        password = findViewById(R.id.text_password);
        PRIJAVA = findViewById(R.id.Prijava);
        register = findViewById(R.id.registruj_se);
        prijava = findViewById(R.id.prijavi_se);

        register.setOnClickListener(this);
        prijava.setOnClickListener(this);
        PRIJAVA.setOnClickListener(this);

        dbHelper = new SmartHospitalDb(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.registruj_se:
                openRegisterActivity();
                break;
            case R.id.prijavi_se:
                username.setVisibility(View.VISIBLE);
                password.setVisibility(View.VISIBLE);
                PRIJAVA.setVisibility(View.VISIBLE);
                break;
            case R.id.Prijava:
                USERNAME = username.getText().toString();
                PASSWORD = password.getText().toString();

                if((USERNAME.toUpperCase().equals("ADMIN")) && (!PASSWORD.isEmpty())){
                    openAdminLoginActivity();
                } else if((!USERNAME.isEmpty()) && (!PASSWORD.isEmpty())) {
                    int sifra = jni.unhashPassword(2234, Integer.parseInt(PASSWORD));
                    if (dbHelper.findKorisnikByUsername(USERNAME) == true && dbHelper.findKorisnikByPassword(String.valueOf(sifra)) == true) {

                        openUserLoginActivity();
                    } else if (dbHelper.findKorisnikByUsername(USERNAME) == false) {
                        String poruka = "Pogresno ste uneli username";
                        Toast.makeText(MainActivity.this, poruka, Toast.LENGTH_LONG).show();
                    } else if (dbHelper.findKorisnikByPassword(USERNAME) == false) {
                        String poruka = "Pogresno ste uneli password";
                        Toast.makeText(MainActivity.this, poruka, Toast.LENGTH_LONG).show();
                    }
                    else {
                        String poruka = "Niste uneli ni username ni password!";
                        Toast.makeText(MainActivity.this, poruka, Toast.LENGTH_LONG).show();
                    }


                }
        }
    }

    void openRegisterActivity(){
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);

    }


    void openUserLoginActivity(){
        Intent intent = new Intent(this, UserActivity.class);
        startActivity(intent);

    }



    void openAdminLoginActivity(){
        Intent intent = new Intent(this, AdminActivity.class);
        startActivity(intent);

    }



    void openLoginActivity(){
        Intent p = new Intent (this, UserActivity.class);
        startActivity(p);

    }
}